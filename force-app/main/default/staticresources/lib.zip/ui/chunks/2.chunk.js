(window.webpackJsonp=window.webpackJsonp||[]).push([[2],{1450:function(p,n,o){p.exports={LEFT_HEADER_WIDTH:"41px",RIGHT_HEADER_WIDTH:"41px"}}}]);
//# sourceMappingURL=2.chunk.js.map