(window.webpackJsonp=window.webpackJsonp||[]).push([[61],{1672:function(n,e,t){t(48)({target:"Number",stat:!0},{isInteger:t(556)})}}]);
//# sourceMappingURL=61.chunk.js.map