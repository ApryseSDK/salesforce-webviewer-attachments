(window.webpackJsonp=window.webpackJsonp||[]).push([[61],{1699:function(n,e,t){t(49)({target:"Number",stat:!0},{isInteger:t(557)})}}]);
//# sourceMappingURL=61.chunk.js.map