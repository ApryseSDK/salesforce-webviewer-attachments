(window.webpackJsonp=window.webpackJsonp||[]).push([[86],{1815:function(n,e,t){t(44)({target:"Number",stat:!0},{isInteger:t(571)})}}]);
//# sourceMappingURL=86.chunk.js.map